import React from 'react';
import { Header } from './components/Header';
import { Timeline } from './components/social/Timeline';
import { Hero } from './components/Hero';
import { FeatureSection } from './components/features/FeatureSection';
import { MessagesOverlay } from './components/social/MessagesOverlay';
import { AgriChatbot } from './components/features/chatbot/AgriChatbot';

export type ActiveFeatureType = 'none' | 'irrigation' | 'pest' | 'marketplace' | 'weather' | 'news' | 'financial' | 'chatbot';
export type NavigationType = 'home' | 'features' | 'marketplace' | 'advisory' | 'news' | 'chatbot';

function App() {
  const [activeFeature, setActiveFeature] = React.useState<ActiveFeatureType>('none');
  const [activeNavigation, setActiveNavigation] = React.useState<NavigationType>('home');
  const [showMessages, setShowMessages] = React.useState(false);

  const handleNavigationSelect = (nav: NavigationType) => {
    setActiveNavigation(nav);
    if (nav === 'home') {
      setActiveFeature('none');
    } else {
      switch (nav) {
        case 'features':
          setActiveFeature('irrigation');
          break;
        case 'marketplace':
          setActiveFeature('marketplace');
          break;
        case 'advisory':
          setActiveFeature('weather');
          break;
        case 'news':
          setActiveFeature('news');
          break;
        case 'chatbot':
          setActiveFeature('chatbot');
          break;
        default:
          setActiveFeature('none');
      }
    }
  };

  const handleFeatureSelect = (feature: ActiveFeatureType) => {
    setActiveFeature(feature);
    setActiveNavigation('features');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white">
      <Header 
        onFeatureSelect={handleNavigationSelect}
        activeFeature={activeNavigation}
        onMessagesClick={() => setShowMessages(true)}
      />
      
      {activeNavigation === 'home' ? (
        <>
          <Hero onFeatureSelect={handleFeatureSelect} />
          <Timeline />
        </>
      ) : (
        <main className="container mx-auto px-4 py-12">
          <FeatureSection activeFeature={activeFeature} />
        </main>
      )}

      {showMessages && <MessagesOverlay onClose={() => setShowMessages(false)} />}
    </div>
  );
}

export default App;
export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  quantity: number;
  unit: 'kg' | 'ton' | 'quintal';
  category: 'grains' | 'vegetables' | 'fruits' | 'other';
  images: string[];
  seller: {
    id: string;
    name: string;
    location: string;
    phone: string;
    email?: string;
    rating: number;
    verified: boolean;
  };
  createdAt: string;
  status: 'available' | 'sold' | 'pending';
}

export interface ProductFormData {
  title: string;
  description: string;
  price: number;
  quantity: number;
  unit: Product['unit'];
  category: Product['category'];
  images: string[];
}
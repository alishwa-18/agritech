export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location: string;
  role: 'farmer' | 'buyer' | 'expert';
  avatar?: string;
  verified: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
}
export interface Post {
  id: string;
  authorId: string;
  content: string;
  images?: string[];
  likes: number;
  comments: Comment[];
  tags: string[];
  createdAt: string;
}

export interface Comment {
  id: string;
  authorId: string;
  content: string;
  likes: number;
  createdAt: string;
}
import type { CropType } from './crops';
import type { SoilType } from './soil';

export interface ChatbotMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface ChatbotContext {
  crops: CropType[];
  soilTypes: SoilType[];
  currentTopic?: string;
  language: 'en' | 'ur' | 'pa';
}

export interface ChatbotResponse {
  message: string;
  context?: {
    topic?: string;
    suggestions?: string[];
  };
}
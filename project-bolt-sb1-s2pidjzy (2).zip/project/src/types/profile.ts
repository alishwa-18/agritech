export interface FarmerProfile {
  id: string;
  name: string;
  phone: string;
  email?: string;
  location: {
    district: string;
    tehsil: string;
    village: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  farms: Farm[];
  certifications: Certification[];
  products: Product[];
  rating: number;
  reviews: Review[];
  joinedDate: string;
  languages: string[];
  profileImage?: string;
}

export interface Farm {
  id: string;
  name: string;
  area: number;
  soilType: string;
  crops: string[];
  irrigation: {
    type: string;
    source: string;
  };
}

export interface Certification {
  name: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  documentUrl?: string;
}

export interface Review {
  id: string;
  rating: number;
  comment: string;
  author: string;
  date: string;
}
export interface SoilType {
  id: string;
  name: string;
  characteristics: string[];
  waterHoldingCapacity: number; // mm/m
  drainageRate: number; // mm/hour
  suitableCrops: string[];
  management: string[];
}

export const soilTypes: SoilType[] = [
  {
    id: 'clay',
    name: 'Clay',
    characteristics: [
      'High water holding capacity',
      'Poor drainage',
      'High nutrient content'
    ],
    waterHoldingCapacity: 200,
    drainageRate: 5,
    suitableCrops: ['Rice', 'Wheat', 'Cotton'],
    management: [
      'Deep plowing',
      'Add organic matter',
      'Improve drainage'
    ]
  },
  {
    id: 'loam',
    name: 'Loam',
    characteristics: [
      'Good water retention',
      'Excellent drainage',
      'High fertility'
    ],
    waterHoldingCapacity: 150,
    drainageRate: 15,
    suitableCrops: ['Wheat', 'Maize', 'Vegetables'],
    management: [
      'Regular organic matter addition',
      'Minimum tillage',
      'Cover cropping'
    ]
  }
];
export type AssistanceType = 'loan' | 'grant' | 'subsidy' | 'investment';
export type ApplicationStatus = 'pending' | 'reviewing' | 'approved' | 'rejected';

export interface FinancialProgram {
  id: string;
  title: string;
  provider: string;
  type: AssistanceType;
  amount: string;
  description: string;
  eligibility: string[];
  requirements: string[];
  duration?: string;
  interestRate?: number;
}

export interface FinancialProvider {
  id: string;
  name: string;
  type: 'bank' | 'government' | 'private' | 'ngo' | 'individual';
  description: string;
  contactInfo: {
    phone: string;
    email?: string;
    website?: string;
    address?: string;
  };
  verificationStatus: 'pending' | 'verified';
  totalFunded: number;
  activePrograms: number;
}

export interface Application {
  id: string;
  programId: string;
  applicantId: string;
  status: ApplicationStatus;
  submittedAt: string;
  lastUpdated: string;
  documents: {
    name: string;
    url: string;
    status: 'pending' | 'verified';
  }[];
  notes?: string;
  amount: number;
}
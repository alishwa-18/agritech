export interface CropDisease {
  id: string;
  name: string;
  scientificName: string;
  symptoms: string[];
  treatment: string[];
  preventiveMeasures: string[];
  images?: string[];
}

export interface CropType {
  id: string;
  name: string;
  scientificName: string;
  waterRequirement: {
    initial: number;
    development: number;
    midSeason: number;
    lateSeason: number;
  };
  diseases: CropDisease[];
  soilTypes: string[];
  growthDuration: number;
  seasonality: ('spring' | 'summer' | 'autumn' | 'winter')[];
}

export const cropTypes: CropType[] = [
  {
    id: 'wheat',
    name: 'Wheat',
    scientificName: 'Triticum aestivum',
    waterRequirement: {
      initial: 3.5,
      development: 4.5,
      midSeason: 5.5,
      lateSeason: 3.0
    },
    diseases: [
      {
        id: 'leaf-rust',
        name: 'Leaf Rust',
        scientificName: 'Puccinia triticina',
        symptoms: [
          'Orange-brown pustules on leaves',
          'Premature leaf death',
          'Reduced grain quality'
        ],
        treatment: [
          'Apply fungicide early in infection',
          'Remove infected plant debris',
          'Use resistant varieties'
        ],
        preventiveMeasures: [
          'Crop rotation',
          'Plant resistant varieties',
          'Early planting'
        ]
      }
    ],
    soilTypes: ['Loam', 'Clay Loam', 'Silt Loam'],
    growthDuration: 120,
    seasonality: ['winter', 'spring']
  },
  {
    id: 'rice',
    name: 'Rice',
    scientificName: 'Oryza sativa',
    waterRequirement: {
      initial: 6.0,
      development: 8.0,
      midSeason: 9.0,
      lateSeason: 6.5
    },
    diseases: [
      {
        id: 'blast',
        name: 'Rice Blast',
        scientificName: 'Magnaporthe oryzae',
        symptoms: [
          'Diamond-shaped lesions',
          'White to gray centers',
          'Withered leaves'
        ],
        treatment: [
          'Apply fungicide at first signs',
          'Improve drainage',
          'Balance nitrogen fertilization'
        ],
        preventiveMeasures: [
          'Use resistant varieties',
          'Proper water management',
          'Balanced fertilization'
        ]
      }
    ],
    soilTypes: ['Clay', 'Heavy Clay', 'Silty Clay'],
    growthDuration: 100,
    seasonality: ['summer']
  }
];
export interface WeatherData {
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  forecast: WeatherForecast[];
  alerts: WeatherAlert[];
}

export interface WeatherForecast {
  date: string;
  temperature: {
    min: number;
    max: number;
  };
  humidity: number;
  rainfall: number;
  windSpeed: number;
  condition: 'clear' | 'cloudy' | 'rain' | 'storm';
}

export interface WeatherAlert {
  type: 'rain' | 'heat' | 'frost' | 'storm';
  severity: 'low' | 'medium' | 'high';
  message: string;
  startDate: string;
  endDate: string;
}
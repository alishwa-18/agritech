export interface IrrigationSchedule {
  cropType: string;
  soilType: string;
  area: number;
  schedule: IrrigationEvent[];
}

export interface IrrigationEvent {
  date: string;
  duration: number;
  waterAmount: number;
}
import type { NewsCategory } from '../utils/news/categories';

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  source: string;
  sourceUrl: string;
  url: string;
  category: NewsCategory;
  image?: string;
}
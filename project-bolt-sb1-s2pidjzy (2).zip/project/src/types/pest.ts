export interface PestAnalysis {
  confidence: number;
  pestName: string;
  scientificName: string;
  description: string;
  treatment: string[];
  preventiveMeasures: string[];
}

export interface ImageAnalysisResult {
  success: boolean;
  analysis?: PestAnalysis;
  error?: string;
}
export interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType;
}

export interface Language {
  code: string;
  name: string;
  nativeName: string;
}

export type Theme = 'light' | 'dark';
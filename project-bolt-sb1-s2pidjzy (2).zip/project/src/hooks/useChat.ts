import { useState, useCallback } from 'react';
import type { Message, ChatRoom } from '../types/chat';

export function useChat(roomId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = useCallback(async (content: string, type: Message['type'] = 'text') => {
    setLoading(true);
    try {
      // TODO: Implement API call
      const newMessage: Message = {
        id: Date.now().toString(),
        senderId: 'currentUser',
        receiverId: 'otherUser',
        content,
        type,
        timestamp: new Date().toISOString(),
        status: 'sent',
      };
      setMessages(prev => [...prev, newMessage]);
    } catch (err) {
      setError('Failed to send message');
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    messages,
    loading,
    error,
    sendMessage,
  };
}
import { useState, useCallback } from 'react';
import type { User, AuthState } from '../types/auth';

export function useAuth() {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    loading: false,
    error: null,
  });

  const login = useCallback(async (email: string, password: string) => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      // TODO: Implement API call
      setState(prev => ({
        ...prev,
        loading: false,
        isAuthenticated: true,
        // user: response.data
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        loading: false,
        error: 'Invalid credentials',
      }));
    }
  }, []);

  const logout = useCallback(() => {
    setState({
      user: null,
      isAuthenticated: false,
      loading: false,
      error: null,
    });
  }, []);

  return {
    ...state,
    login,
    logout,
  };
}
import axios from 'axios';
import type { NewsItem } from '../types/news';

// Mock news data for development/fallback
const MOCK_NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'Pakistan Agricultural Research Council Announces New Wheat Varieties',
    summary: 'PARC has developed new wheat varieties resistant to rust disease and climate change.',
    content: 'The Pakistan Agricultural Research Council (PARC) has announced the development of new wheat varieties...',
    date: new Date().toISOString(),
    source: 'Pakistan Agricultural Research Council',
    sourceUrl: 'https://www.parc.gov.pk',
    url: 'https://www.parc.gov.pk/index.php/en/media-and-news',
    category: 'technology',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800'
  },
  {
    id: '2',
    title: 'Rice Export Prices Rise Amid Global Demand',
    summary: 'Pakistani rice exports see significant price increase in international markets.',
    content: 'The rice export sector has witnessed a substantial increase in prices...',
    date: new Date().toISOString(),
    source: 'Rice Exporters Association of Pakistan',
    sourceUrl: 'https://reap.com.pk',
    url: 'https://reap.com.pk/news',
    category: 'market',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800'
  }
];

// News API endpoints
const NEWS_APIS = {
  DAWN: 'https://www.dawn.com/api/v1/agriculture',
  BUSINESS_RECORDER: 'https://www.brecorder.com/api/agriculture',
  NATION: 'https://nation.com.pk/api/agriculture'
};

async function fetchNewsFromAPI(url: string): Promise<NewsItem[]> {
  try {
    const response = await axios.get(url, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      timeout: 5000 // 5 second timeout
    });

    if (!response.data || !Array.isArray(response.data)) {
      throw new Error('Invalid response format');
    }

    return response.data.map((item: any) => ({
      id: item.id?.toString() || Math.random().toString(),
      title: item.title || '',
      summary: item.summary || item.description || '',
      content: item.content || item.body || '',
      date: new Date(item.date || item.publishedAt || Date.now()).toISOString(),
      source: item.source?.name || 'Agricultural News',
      sourceUrl: item.source?.url || '',
      url: item.url || item.link || '',
      category: determineCategory(item.category || ''),
      image: item.image || item.featuredImage || undefined
    }));
  } catch (error) {
    console.error(`Error fetching from ${url}:`, error);
    return [];
  }
}

function determineCategory(category: string): 'market' | 'technology' | 'policy' | 'weather' {
  const lowerCategory = category.toLowerCase();
  if (lowerCategory.includes('market') || lowerCategory.includes('price') || lowerCategory.includes('trade')) {
    return 'market';
  }
  if (lowerCategory.includes('tech') || lowerCategory.includes('research') || lowerCategory.includes('innovation')) {
    return 'technology';
  }
  if (lowerCategory.includes('policy') || lowerCategory.includes('government') || lowerCategory.includes('regulation')) {
    return 'policy';
  }
  if (lowerCategory.includes('weather') || lowerCategory.includes('climate') || lowerCategory.includes('rain')) {
    return 'weather';
  }
  return 'policy';
}

export async function fetchAgriculturalNews(): Promise<NewsItem[]> {
  let allNews: NewsItem[] = [];

  // Try fetching from APIs
  const apiPromises = Object.values(NEWS_APIS).map(url => fetchNewsFromAPI(url));
  
  try {
    const results = await Promise.allSettled(apiPromises);
    results.forEach(result => {
      if (result.status === 'fulfilled') {
        allNews = [...allNews, ...result.value];
      }
    });
  } catch (error) {
    console.error('Error fetching news:', error);
  }

  // If no news fetched, use mock data
  if (allNews.length === 0) {
    console.log('Using mock news data');
    allNews = MOCK_NEWS;
  }

  // Sort by date
  return allNews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}
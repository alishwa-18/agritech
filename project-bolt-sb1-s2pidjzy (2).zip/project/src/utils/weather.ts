import type { WeatherData, WeatherAlert } from '../types/weather';

export function getWeatherAdvisory(weather: WeatherData): WeatherAlert[] {
  const alerts: WeatherAlert[] = [];
  
  // Temperature alerts
  if (weather.temperature > 40) {
    alerts.push({
      type: 'heat',
      severity: 'high',
      message: 'Extreme heat warning. Ensure adequate irrigation and consider protective measures for crops.',
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    });
  }
  
  // Rainfall alerts
  if (weather.rainfall > 50) {
    alerts.push({
      type: 'rain',
      severity: 'high',
      message: 'Heavy rainfall expected. Risk of flooding and waterlogging. Ensure proper drainage.',
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    });
  }
  
  return alerts;
}

export function getIrrigationRecommendation(weather: WeatherData, cropType: string): string {
  const { temperature, rainfall, humidity } = weather;
  
  if (rainfall > 25) {
    return 'Skip irrigation due to sufficient rainfall';
  }
  
  if (temperature > 35 && humidity < 40) {
    return 'Increase irrigation frequency due to high evaporation';
  }
  
  return 'Maintain regular irrigation schedule';
}
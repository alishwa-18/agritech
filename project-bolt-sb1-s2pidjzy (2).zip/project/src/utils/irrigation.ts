import type { WeatherData } from '../types/weather';
import type { SoilType } from '../types/soil';
import type { CropType } from '../types/crops';
import type { IrrigationSchedule, IrrigationEvent } from '../types/irrigation';

export function generateIrrigationSchedule(
  cropType: string,
  soilType: string,
  area: number
): IrrigationSchedule {
  // For demonstration, generate a sample schedule
  const schedule: IrrigationEvent[] = [
    {
      date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      duration: 2,
      waterAmount: 25
    },
    {
      date: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
      duration: 2.5,
      waterAmount: 30
    },
    {
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      duration: 2,
      waterAmount: 25
    }
  ];

  return {
    cropType,
    soilType,
    area,
    schedule
  };
}

export function calculateIrrigationNeeds(
  crop: CropType,
  soil: SoilType,
  weather: WeatherData,
  area: number
): number {
  const { temperature, humidity, rainfall } = weather;
  const evapotranspiration = calculateEvapotranspiration(temperature, humidity);
  const effectiveRainfall = calculateEffectiveRainfall(rainfall);
  const cropCoefficient = getCropCoefficient(crop);
  
  const waterNeed = (evapotranspiration * cropCoefficient - effectiveRainfall) * area;
  return Math.max(0, waterNeed);
}

function calculateEvapotranspiration(temperature: number, humidity: number): number {
  // Simplified Penman-Monteith equation
  return (0.0023 * (temperature + 17.8) * Math.sqrt(temperature)) * (1 - humidity / 100);
}

function calculateEffectiveRainfall(rainfall: number): number {
  // Simple effective rainfall calculation
  return rainfall * 0.8; // Assume 80% efficiency
}

function getCropCoefficient(crop: CropType): number {
  // Return mid-season coefficient
  return crop.waterRequirement.midSeason / 5; // Normalize to 0-1 range
}
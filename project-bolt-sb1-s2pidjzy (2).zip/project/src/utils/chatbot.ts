import type { ChatbotResponse, ChatbotContext } from '../types/chatbot';
import { cropTypes } from '../types/crops';
import { soilTypes } from '../types/soil';

const knowledgeBase = {
  crops: {
    wheat: {
      cultivation: [
        "Best sowing time is October-November",
        "Requires well-drained loamy soil",
        "Optimal temperature range: 20-25°C",
        "Water requirement: 450-650mm"
      ],
      diseases: [
        "Yellow rust",
        "Leaf rust",
        "Powdery mildew"
      ],
      varieties: [
        "Galaxy-2013",
        "Gold-2016",
        "NARC-2011"
      ]
    },
    rice: {
      cultivation: [
        "Transplanting time: June-July",
        "Requires clay or clay-loam soil",
        "Optimal temperature: 25-35°C",
        "Water requirement: 1500-2000mm"
      ],
      diseases: [
        "Bacterial leaf blight",
        "Rice blast",
        "Brown spot"
      ],
      varieties: [
        "Super Basmati",
        "KSK-434",
        "NIAB-IRRI-9"
      ]
    }
  },
  general: {
    irrigation: [
      "Monitor soil moisture regularly",
      "Use drip irrigation for water efficiency",
      "Irrigate during early morning or evening",
      "Avoid over-irrigation to prevent diseases"
    ],
    fertilizers: [
      "Conduct soil tests before application",
      "Use balanced NPK fertilizers",
      "Apply organic manure for soil health",
      "Follow recommended dosage"
    ],
    pestControl: [
      "Practice integrated pest management",
      "Use biological control when possible",
      "Monitor crops regularly for early detection",
      "Follow safety measures during spraying"
    ]
  }
};

function matchIntent(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('wheat') || lowerMessage.includes('gehun')) {
    return 'wheat';
  }
  if (lowerMessage.includes('rice') || lowerMessage.includes('chawal')) {
    return 'rice';
  }
  if (lowerMessage.includes('water') || lowerMessage.includes('irrigation')) {
    return 'irrigation';
  }
  if (lowerMessage.includes('fertilizer') || lowerMessage.includes('khad')) {
    return 'fertilizers';
  }
  if (lowerMessage.includes('pest') || lowerMessage.includes('disease')) {
    return 'pestControl';
  }
  
  return 'general';
}

function generateResponse(message: string, context: ChatbotContext): ChatbotResponse {
  const intent = matchIntent(message);
  let response = '';
  let suggestions: string[] = [];

  if (intent === 'wheat' || intent === 'rice') {
    const cropInfo = knowledgeBase.crops[intent];
    response = `Here's information about ${intent}:\n\n`;
    response += "Cultivation Tips:\n" + cropInfo.cultivation.join("\n") + "\n\n";
    response += "Common Diseases:\n" + cropInfo.diseases.join("\n") + "\n\n";
    response += "Recommended Varieties:\n" + cropInfo.varieties.join("\n");
    
    suggestions = [
      `What are the best practices for ${intent} cultivation?`,
      `How to control diseases in ${intent}?`,
      `Which ${intent} variety should I choose?`
    ];
  } else {
    const generalInfo = knowledgeBase.general[intent];
    response = generalInfo.join("\n");
    
    suggestions = [
      "Tell me about wheat cultivation",
      "How to manage water efficiently?",
      "What are the best fertilizer practices?"
    ];
  }

  return {
    message: response,
    context: {
      topic: intent,
      suggestions
    }
  };
}

export function processChatMessage(message: string, context: ChatbotContext): ChatbotResponse {
  return generateResponse(message, context);
}
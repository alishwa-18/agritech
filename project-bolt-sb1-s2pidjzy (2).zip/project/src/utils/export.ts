import { saveAs } from 'file-saver';
import type { IrrigationSchedule } from '../types/irrigation';
import type { PestAnalysis } from '../types/pest';
import type { WeatherData } from '../types/weather';

export function exportToCSV(data: any[], filename: string) {
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(header => JSON.stringify(row[header])).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  saveAs(blob, `${filename}.csv`);
}

export function exportToPDF(content: any, filename: string) {
  // Implement PDF export
}

export function exportSchedule(schedule: IrrigationSchedule) {
  const data = schedule.events.map(event => ({
    date: event.date,
    duration: event.duration,
    amount: event.amount,
    notes: event.notes
  }));
  
  exportToCSV(data, `irrigation-schedule-${Date.now()}`);
}

export function exportPestAnalysis(analysis: PestAnalysis) {
  const data = [{
    pest: analysis.name,
    confidence: analysis.confidence,
    treatment: analysis.treatment.join('; '),
    prevention: analysis.preventiveMeasures.join('; ')
  }];
  
  exportToCSV(data, `pest-analysis-${Date.now()}`);
}

export function exportWeatherData(weather: WeatherData) {
  const data = weather.forecast.map(day => ({
    date: day.date,
    temperature: day.temperature,
    rainfall: day.rainfall,
    humidity: day.humidity
  }));
  
  exportToCSV(data, `weather-forecast-${Date.now()}`);
}
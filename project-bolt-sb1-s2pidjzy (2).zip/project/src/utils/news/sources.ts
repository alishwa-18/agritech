// Define news sources and their endpoints
export const NEWS_SOURCES = {
  PARC: {
    name: 'Pakistan Agricultural Research Council',
    url: 'https://www.parc.gov.pk',
    apiEndpoint: 'https://www.parc.gov.pk/api/news'
  },
  REAP: {
    name: 'Rice Exporters Association of Pakistan',
    url: 'https://reap.com.pk',
    apiEndpoint: 'https://reap.com.pk/api/news'
  },
  DAWN_AGRI: {
    name: 'Dawn Agriculture',
    url: 'https://www.dawn.com/agriculture',
    apiEndpoint: 'https://www.dawn.com/api/v1/agriculture'
  }
} as const;

// Mock data for development and fallback
export const MOCK_NEWS = [
  {
    id: '1',
    title: 'Pakistan Agricultural Research Council Announces New Wheat Varieties',
    summary: 'PARC has developed new wheat varieties resistant to rust disease and climate change.',
    content: 'The Pakistan Agricultural Research Council (PARC) has announced the development of new wheat varieties...',
    date: new Date().toISOString(),
    source: NEWS_SOURCES.PARC.name,
    sourceUrl: NEWS_SOURCES.PARC.url,
    url: `${NEWS_SOURCES.PARC.url}/news/wheat-varieties`,
    category: 'technology',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800'
  },
  {
    id: '2',
    title: 'Rice Export Prices Rise Amid Global Demand',
    summary: 'Pakistani rice exports see significant price increase in international markets.',
    content: 'The rice export sector has witnessed a substantial increase in prices...',
    date: new Date().toISOString(),
    source: NEWS_SOURCES.REAP.name,
    sourceUrl: NEWS_SOURCES.REAP.url,
    url: `${NEWS_SOURCES.REAP.url}/news/rice-prices`,
    category: 'market',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800'
  }
];
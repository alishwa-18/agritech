import axios from 'axios';
import type { NewsItem } from '../../types/news';
import { NEWS_SOURCES, MOCK_NEWS } from './sources';
import { determineCategory } from './categories';

const axiosInstance = axios.create({
  timeout: 5000,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
});

async function fetchFromSource(source: typeof NEWS_SOURCES[keyof typeof NEWS_SOURCES]): Promise<NewsItem[]> {
  try {
    const response = await axiosInstance.get(source.apiEndpoint);
    
    if (!response.data) {
      throw new Error('No data received');
    }

    const items = Array.isArray(response.data) ? response.data : response.data.items || [];
    
    return items.map((item: any) => ({
      id: String(item.id || Date.now()),
      title: String(item.title || ''),
      summary: String(item.summary || item.description || ''),
      content: String(item.content || item.body || ''),
      date: new Date(item.date || item.publishedAt || Date.now()).toISOString(),
      source: source.name,
      sourceUrl: source.url,
      url: String(item.url || item.link || ''),
      category: determineCategory(item.category || ''),
      image: item.image || item.featuredImage
    }));
  } catch (error) {
    console.error(`Error fetching from ${source.name}:`, error);
    return [];
  }
}

export async function fetchAllNews(): Promise<NewsItem[]> {
  try {
    const sourcePromises = Object.values(NEWS_SOURCES).map(source => 
      fetchFromSource(source).catch(() => [])
    );

    const results = await Promise.all(sourcePromises);
    const allNews = results.flat();

    if (allNews.length === 0) {
      console.log('Using mock news data');
      return MOCK_NEWS;
    }

    return allNews.sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  } catch (error) {
    console.error('Error fetching news:', error);
    return MOCK_NEWS;
  }
}
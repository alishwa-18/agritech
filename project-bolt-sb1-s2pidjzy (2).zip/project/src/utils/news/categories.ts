export const NEWS_CATEGORIES = ['market', 'technology', 'policy', 'weather'] as const;
export type NewsCategory = typeof NEWS_CATEGORIES[number];

export function determineCategory(category: string): NewsCategory {
  const lowerCategory = category.toLowerCase();
  
  if (lowerCategory.includes('market') || lowerCategory.includes('price') || lowerCategory.includes('trade')) {
    return 'market';
  }
  if (lowerCategory.includes('tech') || lowerCategory.includes('research') || lowerCategory.includes('innovation')) {
    return 'technology';
  }
  if (lowerCategory.includes('weather') || lowerCategory.includes('climate') || lowerCategory.includes('rain')) {
    return 'weather';
  }
  return 'policy';
}
import React from 'react';
import { Book, Users, Sprout, Leaf } from 'lucide-react';

interface ResourceSection {
  title: string;
  icon: React.ReactNode;
  content: string[];
}

export function LearnMore() {
  const resources: ResourceSection[] = [
    {
      title: "Smart Farming Technologies",
      icon: <Sprout className="w-8 h-8 text-green-500" />,
      content: [
        "AI-powered irrigation management for optimal water usage",
        "Machine learning algorithms for pest and disease detection",
        "IoT sensors for real-time crop monitoring",
        "Weather prediction models for agricultural planning",
        "Automated scheduling and alert systems"
      ]
    },
    {
      title: "Market Access & Trade",
      icon: <Users className="w-8 h-8 text-blue-500" />,
      content: [
        "Direct farmer-to-buyer marketplace platform",
        "Real-time market prices and trends",
        "Quality certification and verification",
        "Secure payment processing",
        "Transportation and logistics support"
      ]
    },
    {
      title: "Agricultural Best Practices",
      icon: <Leaf className="w-8 h-8 text-emerald-500" />,
      content: [
        "Crop-specific cultivation guides",
        "Sustainable farming techniques",
        "Soil health management",
        "Integrated pest management",
        "Water conservation methods"
      ]
    },
    {
      title: "Educational Resources",
      icon: <Book className="w-8 h-8 text-purple-500" />,
      content: [
        "Video tutorials on modern farming techniques",
        "Expert webinars and workshops",
        "Agricultural research papers and studies",
        "Community knowledge sharing",
        "Regional farming calendars"
      ]
    }
  ];

  return (
    <div className="bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Learn More About Our Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {resources.map((section, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6"
            >
              <div className="flex items-center gap-3 mb-4">
                {section.icon}
                <h3 className="text-xl font-semibold">{section.title}</h3>
              </div>
              
              <ul className="space-y-3">
                {section.content.map((item, itemIndex) => (
                  <li
                    key={itemIndex}
                    className="flex items-start gap-2 text-gray-600 dark:text-gray-300"
                  >
                    <span className="text-green-500 mt-1">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { AlertCircle, CheckCircle } from 'lucide-react';
import type { PestAnalysis } from '../../../types/pest';

interface Props {
  analysis: PestAnalysis;
}

export function PestAnalysisResult({ analysis }: Props) {
  const confidenceColor = analysis.confidence > 0.8 ? 'text-green-500' : 'text-yellow-500';
  
  return (
    <div className="mt-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Analysis Results</h3>
        <span className={`flex items-center gap-1 ${confidenceColor}`}>
          <CheckCircle className="w-4 h-4" />
          {(analysis.confidence * 100).toFixed(1)}% Confidence
        </span>
      </div>
      
      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
        <h4 className="font-semibold mb-2">{analysis.pestName}</h4>
        <p className="text-sm text-gray-600 dark:text-gray-300 italic mb-4">
          {analysis.scientificName}
        </p>
        <p className="text-sm text-gray-700 dark:text-gray-200 mb-4">
          {analysis.description}
        </p>
        
        <div className="space-y-4">
          <div>
            <h5 className="font-medium mb-2">Recommended Treatment</h5>
            <ul className="list-disc list-inside text-sm space-y-1">
              {analysis.treatment.map((item, index) => (
                <li key={index} className="text-gray-600 dark:text-gray-300">{item}</li>
              ))}
            </ul>
          </div>
          
          <div>
            <h5 className="font-medium mb-2">Preventive Measures</h5>
            <ul className="list-disc list-inside text-sm space-y-1">
              {analysis.preventiveMeasures.map((item, index) => (
                <li key={index} className="text-gray-600 dark:text-gray-300">{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-2 text-sm text-yellow-600 dark:text-yellow-400">
        <AlertCircle className="w-4 h-4" />
        <p>Always consult with a local agricultural expert before applying treatments.</p>
      </div>
    </div>
  );
}
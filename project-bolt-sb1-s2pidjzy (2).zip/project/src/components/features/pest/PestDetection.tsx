import React from 'react';
import { Bug, Upload, Loader2 } from 'lucide-react';
import { analyzeCropImage } from '../../../utils/imageAnalysis';
import { PestAnalysisResult } from './PestAnalysisResult';
import type { ImageAnalysisResult } from '../../../types/pest';

export function PestDetection() {
  const [image, setImage] = React.useState<File | null>(null);
  const [preview, setPreview] = React.useState<string>('');
  const [analysis, setAnalysis] = React.useState<ImageAnalysisResult | null>(null);
  const [loading, setLoading] = React.useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
      setAnalysis(null);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    
    setLoading(true);
    try {
      const result = await analyzeCropImage(image);
      setAnalysis(result);
    } catch (error) {
      setAnalysis({
        success: false,
        error: 'Failed to analyze image. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Bug className="w-6 h-6 text-red-500" />
        <h2 className="text-2xl font-bold">AI Pest Detection</h2>
      </div>

      <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
          id="pest-image-upload"
        />
        <label
          htmlFor="pest-image-upload"
          className="cursor-pointer flex flex-col items-center"
        >
          <Upload className="w-12 h-12 text-gray-400 mb-4" />
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Upload a photo of your affected crop
          </p>
        </label>
      </div>

      {preview && (
        <div className="mt-6">
          <img
            src={preview}
            alt="Uploaded crop"
            className="w-full rounded-lg"
          />
          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="w-full mt-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Analyze Image'
            )}
          </button>
        </div>
      )}

      {analysis?.success && analysis.analysis && (
        <PestAnalysisResult analysis={analysis.analysis} />
      )}

      {analysis?.error && (
        <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg">
          {analysis.error}
        </div>
      )}
    </div>
  );
}
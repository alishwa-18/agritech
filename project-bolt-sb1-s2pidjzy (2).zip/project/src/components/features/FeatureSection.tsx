import React from 'react';
import { IrrigationScheduler } from './irrigation/IrrigationScheduler';
import { PestDetection } from './pest/PestDetection';
import { ProductList } from './marketplace/ProductList';
import { WeatherAlert } from './advisory/WeatherAlert';
import { AgriNews } from './news/AgriNews';
import { FinancialAssistance } from './financial/FinancialAssistance';
import { AgriChatbot } from './chatbot/AgriChatbot';
import type { ActiveFeatureType } from '../../App';

interface Props {
  activeFeature: ActiveFeatureType;
}

export function FeatureSection({ activeFeature }: Props) {
  const mockWeatherData = {
    temperature: 28,
    humidity: 65,
    rainfall: 0,
    windSpeed: 12,
    forecast: [
      {
        date: new Date().toISOString(),
        temperature: { min: 22, max: 30 },
        humidity: 60,
        rainfall: 0,
        windSpeed: 10,
        condition: 'clear'
      }
    ],
    alerts: []
  };

  const renderFeature = () => {
    switch (activeFeature) {
      case 'irrigation':
        return <IrrigationScheduler />;
      case 'pest':
        return <PestDetection />;
      case 'marketplace':
        return <ProductList />;
      case 'weather':
        return <WeatherAlert data={mockWeatherData} />;
      case 'news':
        return <AgriNews />;
      case 'financial':
        return <FinancialAssistance />;
      case 'chatbot':
        return <AgriChatbot />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {renderFeature()}
    </div>
  );
}
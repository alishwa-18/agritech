import React from 'react';
import { Send, Bot, Sparkles, ArrowRight } from 'lucide-react';
import type { ChatbotMessage, ChatbotContext } from '../../../types/chatbot';
import { processChatMessage } from '../../../utils/chatbot';
import { Button } from '../../ui/Button';

export function AgriChatbot() {
  const [messages, setMessages] = React.useState<ChatbotMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I\'m your agricultural assistant. How can I help you today?',
      timestamp: new Date().toISOString()
    }
  ]);
  
  const [input, setInput] = React.useState('');
  const [suggestions, setSuggestions] = React.useState<string[]>([
    'Tell me about wheat cultivation',
    'How to manage irrigation?',
    'What are common crop diseases?'
  ]);
  
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const context: ChatbotContext = {
    crops: [],
    soilTypes: [],
    language: 'en'
  };

  React.useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (content: string) => {
    if (!content.trim()) return;

    // Add user message
    const userMessage: ChatbotMessage = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Process message and get response
    const response = processChatMessage(content, context);
    
    // Add assistant message
    const assistantMessage: ChatbotMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response.message,
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, assistantMessage]);
    if (response.context?.suggestions) {
      setSuggestions(response.context.suggestions);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend(input);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden h-[600px] flex flex-col">
      <div className="p-4 border-b dark:border-gray-700 flex items-center gap-2">
        <Bot className="w-6 h-6 text-green-500" />
        <h2 className="text-xl font-bold">Agricultural Assistant</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.role === 'user'
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700'
              }`}
            >
              <p className="whitespace-pre-line">{message.content}</p>
              <span className="text-xs opacity-75 mt-1 block">
                {new Date(message.timestamp).toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t dark:border-gray-700">
        <div className="mb-4 flex flex-wrap gap-2">
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => handleSend(suggestion)}
              className="flex items-center gap-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-full px-3 py-1"
            >
              <Sparkles className="w-4 h-4" />
              {suggestion}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about crops, diseases, or farming practices..."
            className="flex-1 p-2 rounded-lg border dark:border-gray-600 dark:bg-gray-700"
          />
          <Button type="submit" className="px-4">
            <Send className="w-5 h-5" />
          </Button>
        </form>
      </div>
    </div>
  );
}
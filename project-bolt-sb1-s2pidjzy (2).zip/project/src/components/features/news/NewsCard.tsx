import React from 'react';
import { Share2, BookmarkPlus, ExternalLink } from 'lucide-react';
import type { NewsItem } from '../../../types/news';

interface Props {
  item: NewsItem;
}

export function NewsCard({ item }: Props) {
  return (
    <div className="border-b border-gray-200 dark:border-gray-700 pb-6 last:border-0 last:pb-0">
      {item.image && (
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-48 object-cover rounded-lg mb-4"
        />
      )}
      <div className="flex items-center gap-2 mb-2">
        <a
          href={item.sourceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm text-blue-500 hover:text-blue-600"
        >
          {item.source}
        </a>
        <span className="text-gray-500">•</span>
        <span className="text-sm text-gray-500">
          {new Date(item.date).toLocaleDateString()}
        </span>
      </div>
      <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
        {item.summary}
      </p>
      <div className="flex items-center justify-between text-sm">
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-500 hover:text-blue-600 flex items-center gap-1"
        >
          Read More
          <ExternalLink className="w-4 h-4" />
        </a>
        <div className="flex items-center gap-2">
          <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <BookmarkPlus className="w-4 h-4" />
          </button>
          <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
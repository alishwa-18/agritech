import React from 'react';
import { Newspaper, RefreshCw, Loader2 } from 'lucide-react';
import { Button } from '../../ui/Button';
import { fetchAgriculturalNews } from '../../../utils/news';
import { NewsCard } from './NewsCard';
import type { NewsItem } from '../../../types/news';

export function AgriNews() {
  const [news, setNews] = React.useState<NewsItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [filter, setFilter] = React.useState<NewsItem['category'] | 'all'>('all');

  const fetchNews = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const newsItems = await fetchAgriculturalNews();
      setNews(newsItems);
    } catch (err) {
      setError('Failed to fetch news. Please try again later.');
      console.error('Error fetching news:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchNews();
  }, [fetchNews]);

  const filteredNews = React.useMemo(() => {
    return filter === 'all' ? news : news.filter(item => item.category === filter);
  }, [news, filter]);

  if (error) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <div className="text-center text-red-500 dark:text-red-400">
          <p>{error}</p>
          <Button onClick={fetchNews} className="mt-4">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Newspaper className="w-6 h-6 text-blue-500" />
          <h2 className="text-2xl font-bold">Agricultural News</h2>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={fetchNews}
          disabled={loading}
          className="flex items-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Refreshing...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4" />
              Refresh
            </>
          )}
        </Button>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'market', 'technology', 'policy', 'weather'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat as any)}
            className={`px-4 py-1 rounded-full text-sm whitespace-nowrap ${
              filter === cat
                ? 'bg-blue-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            {cat.charAt(0).toUpperCase() + cat.slice(1)}
          </button>
        ))}
      </div>

      {loading && news.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
        </div>
      ) : (
        <div className="space-y-6">
          {filteredNews.map((item) => (
            <NewsCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}
import React from 'react';
import { Calendar, Clock, Droplet } from 'lucide-react';
import type { IrrigationSchedule } from '../../../types/irrigation';
import { formatDate } from '../../../utils/date';

interface Props {
  schedule: IrrigationSchedule;
}

export function ScheduleDisplay({ schedule }: Props) {
  return (
    <div className="mt-6 space-y-4">
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
        <h3 className="font-semibold mb-2">Schedule Summary</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600 dark:text-gray-400">Crop Type</p>
            <p className="font-medium">{schedule.cropType}</p>
          </div>
          <div>
            <p className="text-gray-600 dark:text-gray-400">Soil Type</p>
            <p className="font-medium">{schedule.soilType}</p>
          </div>
          <div>
            <p className="text-gray-600 dark:text-gray-400">Area</p>
            <p className="font-medium">{schedule.area} acres</p>
          </div>
          <div>
            <p className="text-gray-600 dark:text-gray-400">Total Events</p>
            <p className="font-medium">{schedule.schedule.length}</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="font-semibold">Irrigation Events</h3>
        {schedule.schedule.map((event, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm"
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-blue-500" />
              <div>
                <p className="font-medium">{formatDate(event.date)}</p>
                <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {event.duration} hours
                  </span>
                  <span className="flex items-center gap-1">
                    <Droplet className="w-4 h-4" />
                    {event.waterAmount} mm
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
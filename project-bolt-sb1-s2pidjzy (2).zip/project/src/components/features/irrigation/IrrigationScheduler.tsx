import React from 'react';
import { Droplet, Calendar } from 'lucide-react';
import { generateIrrigationSchedule } from '../../../utils/irrigation';
import { ScheduleDisplay } from './ScheduleDisplay';
import type { IrrigationSchedule } from '../../../types/irrigation';

const soilTypes = ['Clay', 'Loam', 'Sandy', 'Silt'];
const cropTypes = ['Wheat', 'Rice', 'Cotton', 'Sugarcane', 'Maize'];

export function IrrigationScheduler() {
  const [schedule, setSchedule] = React.useState<IrrigationSchedule | null>(null);
  const [formData, setFormData] = React.useState({
    soilType: soilTypes[0],
    cropType: cropTypes[0],
    area: 1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSchedule = generateIrrigationSchedule(
      formData.cropType,
      formData.soilType,
      formData.area
    );
    setSchedule(newSchedule);
  };

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'area' ? parseFloat(value) : value
    }));
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Droplet className="w-6 h-6 text-blue-500" />
        <h2 className="text-2xl font-bold">Smart Irrigation Scheduler</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Soil Type</label>
          <select
            name="soilType"
            value={formData.soilType}
            onChange={handleChange}
            className="w-full p-2 rounded-md border dark:bg-gray-700"
          >
            {soilTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Crop Type</label>
          <select
            name="cropType"
            value={formData.cropType}
            onChange={handleChange}
            className="w-full p-2 rounded-md border dark:bg-gray-700"
          >
            {cropTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Area (Acres)</label>
          <input 
            type="number"
            name="area"
            value={formData.area}
            onChange={handleChange}
            className="w-full p-2 rounded-md border dark:bg-gray-700"
            min="0.1"
            step="0.1"
          />
        </div>

        <button 
          type="submit"
          className="w-full py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
        >
          Generate Schedule
        </button>
      </form>

      {schedule && <ScheduleDisplay schedule={schedule} />}
    </div>
  );
}
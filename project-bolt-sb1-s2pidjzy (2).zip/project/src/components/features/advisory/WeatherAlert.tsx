import React from 'react';
import { Cloud, Droplet, Thermometer, Wind, AlertTriangle } from 'lucide-react';
import type { WeatherData } from '../../../types/weather';
import { getWeatherAdvisory, getIrrigationRecommendation } from '../../../utils/weather';
import { Button } from '../../ui/Button';
import { exportWeatherData } from '../../../utils/export';

export function WeatherAlert({ data }: { data: WeatherData }) {
  const alerts = getWeatherAdvisory(data);
  const irrigationAdvice = getIrrigationRecommendation(data, 'general');

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Weather Advisory</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => exportWeatherData(data)}
        >
          Export Data
        </Button>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Thermometer className="w-5 h-5 text-red-500" />
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Temperature</p>
            <p className="text-lg font-semibold">{data.temperature}°C</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Droplet className="w-5 h-5 text-blue-500" />
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Humidity</p>
            <p className="text-lg font-semibold">{data.humidity}%</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Cloud className="w-5 h-5 text-gray-500" />
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Rainfall</p>
            <p className="text-lg font-semibold">{data.rainfall}mm</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Wind className="w-5 h-5 text-teal-500" />
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Wind Speed</p>
            <p className="text-lg font-semibold">{data.windSpeed} km/h</p>
          </div>
        </div>
      </div>

      {alerts.length > 0 && (
        <div className="mb-6">
          <h3 className="font-semibold mb-2">Weather Alerts</h3>
          <div className="space-y-2">
            {alerts.map((alert, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg flex items-start gap-2 ${
                  alert.severity === 'high'
                    ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300'
                    : alert.severity === 'medium'
                    ? 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-300'
                    : 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                }`}
              >
                <AlertTriangle className="w-5 h-5 mt-0.5" />
                <div>
                  <p className="font-medium">{alert.message}</p>
                  <p className="text-sm opacity-75">
                    {new Date(alert.startDate).toLocaleDateString()} - {new Date(alert.endDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h3 className="font-semibold mb-2">Irrigation Recommendation</h3>
        <p className="text-gray-600 dark:text-gray-300">{irrigationAdvice}</p>
      </div>

      <div>
        <h3 className="font-semibold mb-2">5-Day Forecast</h3>
        <div className="space-y-2">
          {data.forecast.map((day, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded-lg"
            >
              <span>{new Date(day.date).toLocaleDateString()}</span>
              <div className="flex items-center gap-4">
                <span>{day.temperature.min}°C - {day.temperature.max}°C</span>
                <span>{day.rainfall}mm</span>
                <span>{day.condition}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { X, CheckCircle, Clock, AlertTriangle, XCircle } from 'lucide-react';
import type { Application } from '../../../types/financial';
import { Button } from '../../ui/Button';
import { formatDate } from '../../../utils/date';

interface Props {
  application: Application;
  onClose: () => void;
}

export function ApplicationStatus({ application, onClose }: Props) {
  const getStatusIcon = () => {
    switch (application.status) {
      case 'approved':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-6 h-6 text-red-500" />;
      case 'reviewing':
        return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
      default:
        return <Clock className="w-6 h-6 text-blue-500" />;
    }
  };

  const getStatusText = () => {
    switch (application.status) {
      case 'approved':
        return 'Your application has been approved!';
      case 'rejected':
        return 'Your application has been rejected.';
      case 'reviewing':
        return 'Your application is being reviewed.';
      default:
        return 'Your application has been submitted successfully.';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Application Status</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="text-center mb-6">
            {getStatusIcon()}
            <p className="mt-2 text-lg font-medium">{getStatusText()}</p>
          </div>

          <div className="space-y-4 mb-6">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Application ID</p>
              <p className="font-medium">{application.id}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Submitted Date</p>
              <p className="font-medium">{formatDate(application.submittedAt)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Last Updated</p>
              <p className="font-medium">{formatDate(application.lastUpdated)}</p>
            </div>
          </div>

          {application.documents.length > 0 && (
            <div className="mb-6">
              <h3 className="font-medium mb-2">Documents Status</h3>
              <div className="space-y-2">
                {application.documents.map((doc) => (
                  <div
                    key={doc.name}
                    className="flex items-center justify-between text-sm"
                  >
                    <span>{doc.name}</span>
                    <span className={doc.status === 'verified' ? 'text-green-500' : 'text-yellow-500'}>
                      {doc.status === 'verified' ? 'Verified' : 'Pending'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Button onClick={onClose} className="w-full">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { DollarSign, Building, PlusCircle, Search, Filter } from 'lucide-react';
import type { FinancialProgram, Application } from '../../../types/financial';
import { ProgramCard } from './ProgramCard';
import { ProviderForm } from './ProviderForm';
import { ApplicationStatus } from './ApplicationStatus';
import { Button } from '../../ui/Button';
import { Input } from '../../ui/Input';

export function FinancialAssistance() {
  const [showProviderForm, setShowProviderForm] = React.useState(false);
  const [activeApplication, setActiveApplication] = React.useState<Application | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [filter, setFilter] = React.useState<'all' | 'loan' | 'grant' | 'subsidy' | 'investment'>('all');

  const programs: FinancialProgram[] = [
    {
      id: '1',
      title: 'Kissan Dost Loan Program',
      provider: 'Zarai Taraqiati Bank',
      type: 'loan',
      amount: 'Up to Rs. 500,000',
      description: 'Low-interest loans for small-scale farmers to purchase equipment and seeds.',
      eligibility: [
        'Small-scale farmers',
        'Valid CNIC',
        'Land ownership documents'
      ],
      requirements: [
        'Land ownership papers',
        'Bank statement',
        'Income proof'
      ],
      duration: '12 months',
      interestRate: 5
    },
    {
      id: '2',
      title: 'Agricultural Innovation Grant',
      provider: 'Ministry of Agriculture',
      type: 'grant',
      amount: 'Rs. 200,000 - 1,000,000',
      description: 'Grants for implementing innovative farming techniques and technology.',
      eligibility: [
        'Registered farmers',
        'Innovation proposal',
        'Clean credit history'
      ],
      requirements: [
        'Detailed project proposal',
        'Budget plan',
        'Implementation timeline'
      ]
    },
    {
      id: '3',
      title: 'Sustainable Farming Investment',
      provider: 'Green Agriculture Fund',
      type: 'investment',
      amount: 'Rs. 1,000,000 - 5,000,000',
      description: 'Investment funding for sustainable and organic farming projects.',
      eligibility: [
        'Organic farming certification',
        'Business plan',
        'Minimum 5 acres land'
      ],
      requirements: [
        'Organic certification',
        'Environmental impact assessment',
        'Financial projections'
      ],
      duration: '36 months'
    }
  ];

  const filteredPrograms = programs.filter(program => {
    const matchesSearch = program.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      program.provider.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || program.type === filter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <DollarSign className="w-6 h-6 text-green-500" />
          <h2 className="text-2xl font-bold">Financial Assistance Programs</h2>
        </div>
        <Button
          onClick={() => setShowProviderForm(true)}
          className="flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Become a Provider
        </Button>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search programs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="w-4 h-4 text-gray-400" />}
          />
        </div>
        <select
          className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
        >
          <option value="all">All Types</option>
          <option value="loan">Loans</option>
          <option value="grant">Grants</option>
          <option value="subsidy">Subsidies</option>
          <option value="investment">Investments</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredPrograms.map((program) => (
          <ProgramCard
            key={program.id}
            program={program}
            onApply={(programId) => {
              setActiveApplication({
                id: Date.now().toString(),
                programId,
                applicantId: 'current-user',
                status: 'pending',
                submittedAt: new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                documents: [],
                amount: 0
              });
            }}
          />
        ))}
      </div>

      {showProviderForm && (
        <ProviderForm onClose={() => setShowProviderForm(false)} />
      )}

      {activeApplication && (
        <ApplicationStatus
          application={activeApplication}
          onClose={() => setActiveApplication(null)}
        />
      )}
    </div>
  );
}
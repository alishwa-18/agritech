import React from 'react';
import { X } from 'lucide-react';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';
import type { FinancialProvider } from '../../../types/financial';

interface Props {
  onClose: () => void;
}

export function ProviderForm({ onClose }: Props) {
  const [formData, setFormData] = React.useState<Partial<FinancialProvider>>({
    type: 'individual',
    verificationStatus: 'pending',
    totalFunded: 0,
    activePrograms: 0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Submit provider application
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Become a Financial Provider</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Provider Name"
              name="name"
              value={formData.name || ''}
              onChange={handleChange}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Provider Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="w-full p-2 rounded-lg border dark:bg-gray-700"
                  required
                >
                  <option value="individual">Individual</option>
                  <option value="bank">Bank</option>
                  <option value="private">Private Company</option>
                  <option value="ngo">NGO</option>
                </select>
              </div>

              <Input
                label="Phone Number"
                name="contactInfo.phone"
                type="tel"
                value={formData.contactInfo?.phone || ''}
                onChange={handleChange}
                required
              />
            </div>

            <Input
              label="Email"
              name="contactInfo.email"
              type="email"
              value={formData.contactInfo?.email || ''}
              onChange={handleChange}
            />

            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea
                name="description"
                value={formData.description || ''}
                onChange={handleChange}
                className="w-full p-2 rounded-lg border dark:bg-gray-700 min-h-[100px]"
                required
              />
            </div>

            <div className="flex justify-end gap-4">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit">
                Submit Application
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
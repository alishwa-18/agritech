import React from 'react';
import { Building, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import type { FinancialProgram } from '../../../types/financial';
import { Button } from '../../ui/Button';

interface Props {
  program: FinancialProgram;
  onApply: (programId: string) => void;
}

export function ProgramCard({ program, onApply }: Props) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Building className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-semibold">{program.title}</h3>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
            Provider: {program.provider}
          </p>
          <p className="text-green-600 dark:text-green-400 font-semibold mb-2">
            {program.amount}
          </p>
          <p className="text-sm text-gray-700 dark:text-gray-200">
            {program.description}
          </p>
        </div>

        <div className="space-y-4 mb-6">
          <div>
            <h4 className="font-medium mb-2">Eligibility Criteria</h4>
            <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-300">
              {program.eligibility.map((criteria, index) => (
                <li key={index}>{criteria}</li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-2">Required Documents</h4>
            <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-300">
              {program.requirements.map((req, index) => (
                <li key={index}>{req}</li>
              ))}
            </ul>
          </div>

          {program.duration && (
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
              <Clock className="w-4 h-4" />
              <span>Duration: {program.duration}</span>
            </div>
          )}

          {program.interestRate !== undefined && (
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
              <AlertCircle className="w-4 h-4" />
              <span>Interest Rate: {program.interestRate}%</span>
            </div>
          )}
        </div>

        <Button
          onClick={() => onApply(program.id)}
          className="w-full"
        >
          Apply Now
        </Button>
      </div>
    </div>
  );
}
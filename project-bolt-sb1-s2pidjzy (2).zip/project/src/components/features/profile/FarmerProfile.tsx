import React from 'react';
import { MapPin, Phone, Mail, Star, Award, Calendar } from 'lucide-react';
import type { FarmerProfile } from '../../../types/profile';
import { formatDate } from '../../../utils/date';
import { Button } from '../../ui/Button';

interface Props {
  profile: FarmerProfile;
  onEdit?: () => void;
}

export function FarmerProfile({ profile, onEdit }: Props) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      <div className="relative h-32 bg-gradient-to-r from-green-400 to-blue-500">
        {profile.profileImage && (
          <img
            src={profile.profileImage}
            alt={profile.name}
            className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-24 h-24 rounded-full border-4 border-white dark:border-gray-800"
          />
        )}
      </div>

      <div className="pt-16 p-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold">{profile.name}</h2>
          <div className="flex items-center justify-center gap-2 text-gray-600 dark:text-gray-300">
            <MapPin className="w-4 h-4" />
            <span>{profile.location.district}, {profile.location.tehsil}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-gray-500" />
            <span>{profile.phone}</span>
          </div>
          {profile.email && (
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-gray-500" />
              <span>{profile.email}</span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 text-yellow-500" />
            <span>{profile.rating.toFixed(1)} ({profile.reviews.length} reviews)</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-gray-500" />
            <span>Joined {formatDate(profile.joinedDate)}</span>
          </div>
        </div>

        {profile.certifications.length > 0 && (
          <div className="mb-6">
            <h3 className="font-semibold mb-2">Certifications</h3>
            <div className="flex flex-wrap gap-2">
              {profile.certifications.map((cert) => (
                <div
                  key={cert.name}
                  className="flex items-center gap-1 px-3 py-1 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-full text-sm"
                >
                  <Award className="w-4 h-4" />
                  {cert.name}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mb-6">
          <h3 className="font-semibold mb-2">Farms</h3>
          <div className="space-y-3">
            {profile.farms.map((farm) => (
              <div
                key={farm.id}
                className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
              >
                <h4 className="font-medium">{farm.name}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {farm.area} acres • {farm.soilType} soil
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Crops: {farm.crops.join(', ')}
                </p>
              </div>
            ))}
          </div>
        </div>

        {onEdit && (
          <Button
            variant="outline"
            className="w-full"
            onClick={onEdit}
          >
            Edit Profile
          </Button>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';
import type { FarmerProfile } from '../../../types/profile';

interface Props {
  profile: FarmerProfile;
  onSave: (profile: FarmerProfile) => void;
  onCancel: () => void;
}

export function ProfileEditor({ profile, onSave, onCancel }: Props) {
  const [formData, setFormData] = React.useState(profile);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <Input
          label="Phone"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          required
        />
        <Input
          label="Email"
          name="email"
          type="email"
          value={formData.email || ''}
          onChange={handleChange}
        />
        <Input
          label="District"
          name="location.district"
          value={formData.location.district}
          onChange={handleChange}
          required
        />
        <Input
          label="Tehsil"
          name="location.tehsil"
          value={formData.location.tehsil}
          onChange={handleChange}
          required
        />
        <Input
          label="Village"
          name="location.village"
          value={formData.location.village}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          Save Changes
        </Button>
      </div>
    </form>
  );
}
import React from 'react';
import { Plus, Search, Filter } from 'lucide-react';
import type { Product } from '../../../types/marketplace';
import { ProductCard } from './ProductCard';
import { ProductForm } from './ProductForm';
import { ContactModal } from './ContactModal';
import { Button } from '../../ui/Button';
import { Input } from '../../ui/Input';

const categories = ['all', 'grains', 'vegetables', 'fruits', 'other'] as const;

export function ProductList() {
  const [products, setProducts] = React.useState<Product[]>([
    {
      id: '1',
      title: 'Premium Wheat',
      description: 'High-quality wheat grain, freshly harvested',
      price: 3000,
      quantity: 100,
      unit: 'quintal',
      category: 'grains',
      images: ['https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800'],
      seller: {
        id: '1',
        name: 'Ahmad Khan',
        location: 'Multan, Punjab',
        phone: '+923001234567',
        rating: 4.5,
        verified: true
      },
      createdAt: new Date().toISOString(),
      status: 'available'
    },
    {
      id: '2',
      title: 'Fresh Tomatoes',
      description: 'Organically grown tomatoes, perfect for commercial use',
      price: 80,
      quantity: 500,
      unit: 'kg',
      category: 'vegetables',
      images: ['https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=800'],
      seller: {
        id: '2',
        name: 'Muhammad Ali',
        location: 'Lahore, Punjab',
        phone: '+923007654321',
        rating: 4.8,
        verified: true
      },
      createdAt: new Date().toISOString(),
      status: 'available'
    }
  ]);

  const [showForm, setShowForm] = React.useState(false);
  const [contactProduct, setContactProduct] = React.useState<Product | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [category, setCategory] = React.useState<typeof categories[number]>('all');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = category === 'all' || product.category === category;
    return matchesSearch && matchesCategory;
  });

  const handleAddProduct = (product: Omit<Product, 'id' | 'seller' | 'createdAt' | 'status'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      seller: {
        id: 'current-user',
        name: 'Current User',
        location: 'Your Location',
        phone: '+923001234567',
        rating: 0,
        verified: false
      },
      createdAt: new Date().toISOString(),
      status: 'available'
    };
    setProducts(prev => [...prev, newProduct]);
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Agricultural Products</h2>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Product
        </Button>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="w-4 h-4 text-gray-400" />}
          />
        </div>
        <select
          className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
          value={category}
          onChange={(e) => setCategory(e.target.value as typeof category)}
        >
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onContact={() => setContactProduct(product)}
          />
        ))}
      </div>

      {showForm && (
        <ProductForm
          onSubmit={handleAddProduct}
          onClose={() => setShowForm(false)}
        />
      )}

      {contactProduct && (
        <ContactModal
          product={contactProduct}
          onClose={() => setContactProduct(null)}
        />
      )}
    </div>
  );
}
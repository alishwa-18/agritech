import React from 'react';
import { MapPin, Star, Phone } from 'lucide-react';
import type { Product } from '../../../types/marketplace';
import { Button } from '../../ui/Button';
import { formatDate } from '../../../utils/date';

interface Props {
  product: Product;
  onContact: () => void;
}

export function ProductCard({ product, onContact }: Props) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      <img
        src={product.images[0]}
        alt={product.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">{product.title}</h3>
          <span className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 text-sm rounded-full">
            {product.category}
          </span>
        </div>

        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
          {product.description}
        </p>

        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-xl font-bold">
              Rs. {product.price.toLocaleString()}/{product.unit}
            </p>
            <p className="text-sm text-gray-500">
              Quantity: {product.quantity} {product.unit}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-500" />
            <span>{product.seller.rating}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-4 text-sm text-gray-600 dark:text-gray-300">
          <MapPin className="w-4 h-4" />
          <span>{product.seller.location}</span>
        </div>

        <Button onClick={onContact} className="w-full flex items-center justify-center gap-2">
          <Phone className="w-4 h-4" />
          Contact Seller
        </Button>
      </div>
    </div>
  );
}
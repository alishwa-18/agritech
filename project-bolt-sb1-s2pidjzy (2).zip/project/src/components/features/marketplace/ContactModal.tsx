import React from 'react';
import { X, Phone, Mail, MapPin, Star, Shield, MessageCircle } from 'lucide-react';
import type { Product } from '../../../types/marketplace';
import { Button } from '../../ui/Button';
import { ChatWindow } from '../chat/ChatWindow';

interface Props {
  product: Product;
  onClose: () => void;
}

export function ContactModal({ product, onClose }: Props) {
  const [showChat, setShowChat] = React.useState(false);

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-40">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Contact Seller</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                  <span className="text-lg font-bold text-green-700 dark:text-green-300">
                    {product.seller.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{product.seller.name}</h3>
                    {product.seller.verified && (
                      <Shield className="w-4 h-4 text-blue-500" />
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-600 dark:text-gray-300">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span>{product.seller.rating} rating</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-gray-500" />
                  <span>{product.seller.location}</span>
                </div>
                
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-500" />
                  <span>{product.seller.phone}</span>
                </div>

                {product.seller.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-gray-500" />
                    <span>{product.seller.email}</span>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium mb-2">Product Details</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {product.title} - {product.quantity} {product.unit} at Rs. {product.price}/{product.unit}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <Button
                  className="flex items-center justify-center gap-2"
                  onClick={() => window.location.href = `tel:${product.seller.phone}`}
                >
                  <Phone className="w-4 h-4" />
                  Call
                </Button>
                {product.seller.email && (
                  <Button
                    variant="outline"
                    className="flex items-center justify-center gap-2"
                    onClick={() => window.location.href = `mailto:${product.seller.email}`}
                  >
                    <Mail className="w-4 h-4" />
                    Email
                  </Button>
                )}
                <Button
                  variant="secondary"
                  className="flex items-center justify-center gap-2"
                  onClick={() => setShowChat(true)}
                >
                  <MessageCircle className="w-4 h-4" />
                  Chat
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showChat && (
        <ChatWindow
          recipientId={product.seller.id}
          recipientName={product.seller.name}
          onClose={() => setShowChat(false)}
        />
      )}
    </>
  );
}
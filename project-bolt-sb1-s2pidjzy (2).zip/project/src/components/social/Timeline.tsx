import React from 'react';
import { MessageCircle, Heart, Share2, Repeat2 } from 'lucide-react';
import type { Post } from '../../types/community';

export function Timeline() {
  const [posts, setPosts] = React.useState<Post[]>([
    {
      id: '1',
      authorId: '1',
      content: 'Just implemented drip irrigation in my wheat field. Seeing 30% water savings already! #SmartFarming #WaterConservation',
      likes: 45,
      comments: [],
      tags: ['SmartFarming', 'WaterConservation'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      authorId: '2',
      content: 'Market update: Cotton prices up by 15% this week. Good time to sell! 📈 #AgriMarket #Cotton',
      images: ['https://images.unsplash.com/photo-1599824701954-d1d141704de9?w=800'],
      likes: 32,
      comments: [],
      tags: ['AgriMarket', 'Cotton'],
      createdAt: new Date().toISOString()
    }
  ]);

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(post => 
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="space-y-6">
        {posts.map(post => (
          <div key={post.id} className="bg-white dark:bg-gray-800 rounded-xl shadow p-4">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                <span className="text-green-700 dark:text-green-300 font-semibold">
                  {post.authorId === '1' ? 'A' : 'B'}
                </span>
              </div>
              <div>
                <p className="font-semibold">
                  {post.authorId === '1' ? 'Ahmad Khan' : 'Bilal Ahmed'}
                </p>
                <p className="text-sm text-gray-500">
                  {new Date(post.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>

            <p className="mb-3">{post.content}</p>

            {post.images?.map((image, index) => (
              <img
                key={index}
                src={image}
                alt="Post content"
                className="rounded-lg mb-3 w-full"
              />
            ))}

            <div className="flex items-center justify-between text-gray-500">
              <button
                onClick={() => handleLike(post.id)}
                className="flex items-center gap-1 hover:text-red-500"
              >
                <Heart className="w-5 h-5" />
                <span>{post.likes}</span>
              </button>
              <button className="flex items-center gap-1 hover:text-blue-500">
                <MessageCircle className="w-5 h-5" />
                <span>{post.comments.length}</span>
              </button>
              <button className="flex items-center gap-1 hover:text-green-500">
                <Repeat2 className="w-5 h-5" />
              </button>
              <button className="flex items-center gap-1 hover:text-purple-500">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { X, Search, MessageCircle } from 'lucide-react';
import { ChatWindow } from '../features/chat/ChatWindow';

interface Props {
  onClose: () => void;
}

export function MessagesOverlay({ onClose }: Props) {
  const [selectedChat, setSelectedChat] = React.useState<string | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');

  const chats = [
    { id: '1', name: 'Ahmad Khan', lastMessage: 'What\'s the current price for wheat?', time: '2h ago' },
    { id: '2', name: 'Bilal Ahmed', lastMessage: 'The cotton shipment will arrive tomorrow', time: '5h ago' }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex justify-end">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 h-full">
        <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-bold">Messages</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-full border dark:border-gray-600 dark:bg-gray-700"
            />
          </div>

          <div className="space-y-2">
            {chats.map(chat => (
              <button
                key={chat.id}
                onClick={() => setSelectedChat(chat.id)}
                className="w-full p-3 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-green-700 dark:text-green-300" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{chat.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                    {chat.lastMessage}
                  </p>
                </div>
                <span className="text-xs text-gray-500">{chat.time}</span>
              </button>
            ))}
          </div>
        </div>

        {selectedChat && (
          <ChatWindow
            recipientId={selectedChat}
            recipientName={chats.find(c => c.id === selectedChat)?.name || ''}
            onClose={() => setSelectedChat(null)}
          />
        )}
      </div>
    </div>
  );
}
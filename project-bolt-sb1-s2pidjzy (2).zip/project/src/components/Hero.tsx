import React from 'react';
import { GetStarted } from './GetStarted';
import { LearnMore } from './LearnMore';
import type { ActiveFeatureType } from '../App';

interface Props {
  onFeatureSelect: (feature: ActiveFeatureType) => void;
}

export function Hero({ onFeatureSelect }: Props) {
  const [activeSection, setActiveSection] = React.useState<'none' | 'start' | 'learn'>('none');

  return (
    <>
      <div className="relative overflow-hidden bg-gradient-to-b from-green-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-12 md:py-24">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl lg:text-6xl font-bold mb-4 md:mb-6">
              Empowering Pakistan's Farmers
            </h1>
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-6 md:mb-8 max-w-2xl mx-auto">
              Access smart farming tools, market insights, and expert advice to grow your agricultural business
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={() => setActiveSection('start')}
                className="w-full sm:w-auto px-6 md:px-8 py-2 md:py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Get Started
              </button>
              <button
                onClick={() => setActiveSection('learn')}
                className="w-full sm:w-auto px-6 md:px-8 py-2 md:py-3 border border-green-600 text-green-600 rounded-lg hover:bg-green-50 dark:hover:bg-gray-800 transition-colors"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>

      {activeSection === 'start' && <GetStarted onFeatureSelect={onFeatureSelect} />}
      {activeSection === 'learn' && <LearnMore />}
    </>
  );
}
import React from 'react';
import { ArrowRight, Droplet, Bug, ShoppingBag, CloudSun, Newspaper, DollarSign } from 'lucide-react';
import { Button } from './ui/Button';
import type { ActiveFeatureType } from '../App';

interface FeatureCard {
  id: ActiveFeatureType;
  icon: React.ReactNode;
  title: string;
  description: string;
  action: string;
}

interface Props {
  onFeatureSelect: (feature: ActiveFeatureType) => void;
}

export function GetStarted({ onFeatureSelect }: Props) {
  const features: FeatureCard[] = [
    {
      id: 'irrigation',
      icon: <Droplet className="w-8 h-8 text-blue-500" />,
      title: "Smart Irrigation Scheduler",
      description: "Get AI-powered irrigation schedules based on crop type, soil conditions, and weather forecasts.",
      action: "Start Scheduling"
    },
    {
      id: 'pest',
      icon: <Bug className="w-8 h-8 text-red-500" />,
      title: "AI Pest Detection",
      description: "Upload photos of affected crops for instant pest identification and treatment recommendations.",
      action: "Detect Pests"
    },
    {
      id: 'marketplace',
      icon: <ShoppingBag className="w-8 h-8 text-green-500" />,
      title: "Agricultural Marketplace",
      description: "Buy and sell agricultural products directly with other farmers and buyers.",
      action: "Visit Market"
    },
    {
      id: 'weather',
      icon: <CloudSun className="w-8 h-8 text-yellow-500" />,
      title: "Weather Advisory",
      description: "Get real-time weather updates and agricultural recommendations for your region.",
      action: "Check Weather"
    },
    {
      id: 'news',
      icon: <Newspaper className="w-8 h-8 text-purple-500" />,
      title: "Agricultural News",
      description: "Stay updated with the latest agricultural news, policies, and market trends.",
      action: "Read News"
    },
    {
      id: 'financial',
      icon: <DollarSign className="w-8 h-8 text-emerald-500" />,
      title: "Financial Assistance",
      description: "Access loans, grants, and financial support programs for agricultural development.",
      action: "Explore Programs"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12">Get Started with KisanConnect</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {features.map((feature) => (
          <div
            key={feature.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 md:p-6 hover:shadow-xl transition-shadow"
          >
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-lg md:text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-sm md:text-base text-gray-600 dark:text-gray-300 mb-4">{feature.description}</p>
            <Button 
              onClick={() => onFeatureSelect(feature.id)}
              className="w-full flex items-center justify-center gap-2"
            >
              {feature.action}
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}